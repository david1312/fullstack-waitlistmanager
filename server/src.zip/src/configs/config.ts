import dotenv from "dotenv";
dotenv.config();

export const config: Readonly<{
  POSTGRES_USER: string;
  POSTGRES_PASSWORD: string;
  POSTGRES_DB: string;
  POSTGRES_HOST: string;
  POSTGRES_PORT: number;
  SERVER_PORT: number;
  API_BASE_URL: string;

  SERVICE_TIME_PER_PERSON: number;
  RESTAURANT_CAPACITY: number;
  NOTIF_FIRST_LATE: number;
  NOTIF_REQUEUE: number;
  REQUEUE_CHANCE: number;
}> = {
  POSTGRES_USER: process.env.POSTGRES_USER || "",
  POSTGRES_PASSWORD: process.env.POSTGRES_PASSWORD || "",
  POSTGRES_DB: process.env.POSTGRES_DB || "",
  POSTGRES_HOST: process.env.POSTGRES_HOST || "localhost",
  POSTGRES_PORT: parseInt(process.env.POSTGRES_PORT || "5432", 10),

  SERVER_PORT: parseInt(process.env.SERVER_PORT || "8080", 10),
  API_BASE_URL: "/api",

  SERVICE_TIME_PER_PERSON: 3, //seconds
  RESTAURANT_CAPACITY: 10,
  NOTIF_FIRST_LATE: 10, // seconds
  NOTIF_REQUEUE: 20, // seconds
  REQUEUE_CHANCE: 1,
};
